
![image](https://github.com/Sankhya-BPMG/LimpezaDeBase/assets/80463617/9c58e1e6-c4b5-4cc3-8808-72396012a08e)


![image](https://github.com/Sankhya-BPMG/LimpezaDeBase/assets/80463617/91a0fb0c-75b8-4a0a-aa9f-f68568130640)


![image](https://github.com/Sankhya-BPMG/LimpezaDeBase/assets/80463617/1e02353e-93b6-4e35-846d-f89561d02bae)
