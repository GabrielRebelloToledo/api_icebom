package br.com.helpers;

import java.util.ArrayList;
import java.util.List;

import br.com.sankhya.extensions.actionbutton.AcaoRotinaJava;
import br.com.sankhya.extensions.actionbutton.ContextoAcao;
import br.com.sankhya.extensions.actionbutton.QueryExecutor;
import br.com.sankhya.extensions.actionbutton.Registro;



public class LimpaBase implements AcaoRotinaJava {

	@Override
	public void doAction(ContextoAcao contexto) throws Exception {
		
		Registro[] linhasSelecionadas = contexto.getLinhas();
		
		List<Query> querys = new ArrayList<Query>();
		
		for (Registro linha : linhasSelecionadas) {
			QueryExecutor query = contexto.getQuery();

		
			query.setParam("P_COD", linha.getCampo("NROUNICO"));

			query.nativeSelect(
					"SELECT NROUNICO, QUERY FROM AD_LIMPABASE WHERE NROUNICO = {P_COD}");

			while (query.next()) {
				
				Integer unico = query.getInt("NROUNICO");
				String query_intern = query.getString("QUERY");
				
				Query sql = new Query(unico, query_intern);
				querys.add(sql);
				
			}
             query.close();
		}
		
		if (!querys.isEmpty()) {
			for (Query sql : querys) {
				limparbase(contexto, sql);
		        //contexto.setMensagemRetorno(financeiro.getNotas());
			}
		}
		
	}

	private void limparbase(ContextoAcao contexto, Query sql) throws Exception {
		// TODO Auto-generated method stub
		try {
			
			QueryExecutor query_limpa = contexto.getQuery();
			query_limpa.update(sql.getQuery());
			query_limpa.close();
			
			
			QueryExecutor query_sucesso = contexto.getQuery();
			
			query_sucesso.update("UPDATE AD_LIMPABASE SET HISTORICO = 'OK!' WHERE NROUNICO = " + sql.getCodigoquery());
			query_sucesso.close();
			
		}catch(Exception e ) {
			
			    QueryExecutor query_erro = contexto.getQuery();
			
				query_erro.update("UPDATE AD_LIMPABASE SET HISTORICO = " + e.toString() + " WHERE NROUNICO = " + sql.getCodigoquery());
				query_erro.close();
			
		}
	}
	
	
}
