package br.com.helpers;


public class Query {
	private Integer codigoquery;
	private String query;
	

	public Query(Integer codigoquery, String query) {

		this.setCodigoquery(codigoquery);
		this.setQuery(query);
		
	}


	public String getQuery() {
		return query;
	}


	public void setQuery(String query) {
		this.query = query;
	}


	public Integer getCodigoquery() {
		return codigoquery;
	}


	public void setCodigoquery(Integer codigoquery) {
		this.codigoquery = codigoquery;
	}


	
}
