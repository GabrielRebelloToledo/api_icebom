package br.com.helpers;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import br.com.sankhya.extensions.actionbutton.AcaoRotinaJava;
import br.com.sankhya.extensions.actionbutton.ContextoAcao;
import br.com.sankhya.extensions.actionbutton.Registro;

public class InsereDadosSqlServer implements AcaoRotinaJava {

	@Override
	public void doAction(ContextoAcao contexto) throws Exception {
		
		
		String diretorio = (String) contexto.getParam("DIRETORIO");
	 	 //String nomeArquivo = "/home/gabriel/Documentos/teste.json";
		//String nomeArquivo = "/home/mgeweb/repositorio/impressao/sql_sql_server.json";
		String nomeArquivo = diretorio + "/sql_sql_server.json";
		
    	 List<String> values = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(nomeArquivo))) {
            StringBuilder jsonBuilder = new StringBuilder();
            String linha;
            while ((linha = br.readLine()) != null) {
                jsonBuilder.append(linha);
            }

            JSONArray jsonArray = new JSONArray(jsonBuilder.toString());

            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject objetoJson = jsonArray.getJSONObject(i); 
                
                
                for (String key : objetoJson.keySet()) {
                    // Get the value associated with the key
                    String value = objetoJson.getString(key);
                    
                    // Add value to the list
                    values.add(value);
                }
                
            }
            
            for (String value : values) {
                
                inserirDados(contexto, value);
            }

        } catch (IOException | JSONException e) {
            e.printStackTrace();
        }
        contexto.setMensagemRetorno("Rotina processada com sucesso !");
	}
	
	
	  public static void inserirDados (ContextoAcao contexto, String dado) throws Exception {
	    	
		  Registro inclusao = contexto.novaLinha("AD_LIMPABASE");
		  
		  inclusao.setCampo("QUERY", dado);
		  inclusao.save();
	    	
		    
	    }
	
}


