
let tabelaAtual = "";
let editable = false;
let NROPRODUCAO = "";
let NROANALISE = "";

let USUARIO = "";
let ANALISTACQ = 'N';
let ANALISTAQUALDIADE = 'N';
let CONFERENTE = 'N';
let IMPRESSAO = 'N';
let STATUS = "Outro";

let VALOR_FILTRO = "Selecione";


const preenchimento = "Em Preenchimento CQ";
const emAnaliseCQ = "Em Conferência CQ";
const emvalidacaoq = "Em Validação Qualidade"
const retornoCQ = "Retornado Para CQ";
const finalizado = "Concluído";
const reprovConcluida = "Analise Reprovada / Concluída";


async function capturarUsuarioAcessosUsuario() {

    // Construir a consulta
    var query = `SELECT NVL(AD_CONFERENTE, 'N') AS AD_CONFERENTE, NVL(AD_ANALISTACQ,'N') AS AD_ANALISTACQ , NVL(AD_ANALISTADOCSCQ,'N') AS AD_ANALISTADOCSCQ, NVL(AD_IMPRESSAOQUALIT,'N') AS AD_IMPRESSAOQUALIT, (CODUSU || ' - ' || NOMEUSU) AS USUARIO FROM TSIUSU WHERE CODUSU = STP_GET_CODUSULOGADO()`;

    // Executar a consulta usando a biblioteca JX
    let resultado = await JX.consultar(query);

    if (resultado.length == 0) { return; }
    else { resultado = resultado[0]; }

    ANALISTACQ = resultado.AD_ANALISTACQ;
    ANALISTAQUALDIADE = resultado.AD_ANALISTADOCSCQ;
    CONFERENTE = resultado.AD_CONFERENTE;
    IMPRESSAO = resultado.AD_IMPRESSAOQUALIT;
    USUARIO = resultado.USUARIO;


    if (ANALISTAQUALDIADE == 'S') {
        document.getElementsByClassName("buttonRegistro")[0].style.visibility = "hidden";
    }

}

capturarUsuarioAcessosUsuario();

function novo(tabela, novoregistro) {

    if (novoregistro == true) {
        limparDivAnalises();
        NROPRODUCAO = "";
        NROANALISE = "";
    }

    editable = false;

    tabelaAtual = tabela;

    console.log("Entrou! " + tabela);

    document.getElementsByClassName("tabela")[0].style.display = "none";
    document.getElementsByClassName("formR")[0].style.display = "block";


    var query = `SELECT CASE WHEN CAM.TIPCAMPO = 'F' THEN 'S' ELSE 'N' END AS STEP, CAM.NOMECAMPO, CAM.NOMETAB, CAM.DESCRCAMPO, CASE WHEN CAM.TIPCAMPO = 'S' THEN 'text' WHEN CAM.TIPCAMPO = 'D' THEN 'date' WHEN CAM.TIPCAMPO IN ('I','F') THEN 'number' END AS TIPO, `;
    query += ` AD_REQUERIDO(CAM.NOMETAB,CAM.NOMECAMPO) AS OBRIGATORIO, AD_READONLY(CAM.NOMETAB,CAM.NOMECAMPO) AS READ, MINMAX.MIN, MINMAX.MAX FROM TDDCAM CAM LEFT JOIN AD_CAMPOSMINMAX MINMAX ON CAM.NOMETAB = MINMAX.NOMETABELA AND CAM.NOMECAMPO = MINMAX.NOMECAMPO `;
    query += ` WHERE CAM.NOMETAB = '${tabela}' AND CAM.CALCULADO = 'N' ORDER BY CAM.ORDEM ASC`;


    executeQuery(query, [], function (value) {
        var dadosTabela = JSON.parse(value);
        if (dadosTabela.length > 0) {
            // Chama a função para criar o formulário dinâmico
            var formularioDiv = document.getElementById("formulario");
            formularioDiv.innerHTML = "";
            criarFormulario(dadosTabela);
        }

    }, function (error) {
        alert("Erro ao carregar os dados: " + error);
    });
}


function criarFormulario(dados, valores = {}) {
    var form = document.createElement("form");
    form.className = "form-group";

    // Cria um container de grid para os campos do formulário
    var row = document.createElement("div");
    row.className = "row";

    dados.forEach(function (campo, index) {
        // Cria uma coluna
        var col = document.createElement("div");
        col.className = "col-md-6 mb-3"; // Ajuste a largura da coluna conforme necessário

        // Cria o label
        var label = document.createElement("label");
        label.setAttribute("for", campo.NOMECAMPO);
        label.textContent = campo.DESCRCAMPO;
        label.className = "form-label"; // Classe do Bootstrap

        // Cria o input
        var input = document.createElement("input");
        input.setAttribute("type", campo.TIPO); // Você pode definir o tipo dinamicamente se necessário
        input.setAttribute("id", campo.NOMECAMPO);
        input.setAttribute("name", campo.NOMETABELA + "[" + campo.NOMECAMPO + "]");
        input.className = "form-control"; // Classe do Bootstrap

        if (campo.OBRIGATORIO === "true") {
            input.setAttribute("required", "true");
            input.classList.add("is-invalid");
        }

        if (campo.STEP === "S") {
            input.setAttribute("step", "0.01");
        }

        // Preenche os campos com os valores da linha, se disponíveis
        if (valores[campo.NOMECAMPO]) {
            input.value = valores[campo.NOMECAMPO];


            if (valores[campo.NOMECAMPO] != null) {
                editable = true;
                // Remove a classe 'is-invalid' e adiciona 'is-valid' se o campo estiver preenchido
                input.classList.remove("is-invalid");
                input.classList.add("is-valid");

            } else {
                editable = false;
            }
        }


        if (campo.READ === "true") {
            input.setAttribute("readonly", "true");
        }

        // Define min e max se forem especificados no objeto campo
        input.setAttribute("min", campo.MIN);
        input.setAttribute("max", campo.MAX);

        var inputContainer = document.createElement("div");
        inputContainer.style.position = "relative";
        inputContainer.className = "input-container";
        inputContainer.appendChild(input);

        // Condição para verificar o tipo e configurar min/max se for número
        if (campo.TIPO === 'number') {
            var minMaxInfo = document.createElement("span");
            minMaxInfo.className = "min-max-info";
            minMaxInfo.style.position = "absolute";
            minMaxInfo.style.top = "100%";  // Posiciona 100% abaixo do input
            minMaxInfo.style.right = "0";   // Alinha à direita
            minMaxInfo.style.fontSize = "0.8em";
            minMaxInfo.style.color = "#888";
            minMaxInfo.style.marginTop = "3px"; // Ajusta a margem superior

            // Define o texto com valores min e max
            if (campo.MIN > 0 && campo.MAX > 0) {
                minMaxInfo.textContent = `Min: ${campo.MIN}, Max: ${campo.MAX}`;
            } else if (campo.MIN > 0) {
                minMaxInfo.textContent = `Min: ${campo.MIN}`;
            } else if (campo.MAX > 0) {
                minMaxInfo.textContent = `Max: ${campo.MAX}`;
            }

            // Adiciona o minMaxInfo ao contêiner do input
            inputContainer.appendChild(minMaxInfo);
        }


        // Cria um elemento de feedback para mostrar mensagens de erro
        var feedback = document.createElement("div");
        feedback.className = "invalid-feedback";
        feedback.textContent = "Este campo é obrigatório."; // Mensagem de feedback

        // Adiciona o label, input e feedback à coluna
        col.appendChild(label);
        col.appendChild(input);
        if (typeof inputContainer !== 'undefined') {
            col.appendChild(inputContainer);
        }
        col.appendChild(feedback);

        // Adiciona a coluna à linha
        row.appendChild(col);

        // Adiciona uma quebra de linha para layout (opcional)
        if ((index + 1) % 2 === 0) { // Se tiver duas colunas por linha
            form.appendChild(row);
            row = document.createElement("div");
            row.className = "row";
        }
    });

    // Adiciona a última linha se necessário
    if (row.children.length > 0) {
        form.appendChild(row);
    }

    // Adiciona um botão de envio
    var submitButton = document.createElement("button");
    submitButton.setAttribute("type", "submit");
    submitButton.textContent = "Enviar";
    submitButton.className = "btn btn-primary"; // Classe do Bootstrap
    form.appendChild(submitButton);

    // Adiciona o formulário ao div com id "formulario"
    var formularioDiv = document.getElementById("formulario");
    formularioDiv.innerHTML = ""; // Limpa o conteúdo existente
    formularioDiv.appendChild(form);

    // Adiciona um manipulador de evento para capturar a submissão do formulário
    form.addEventListener("submit", function (event) {
        event.preventDefault(); // Impede o envio padrão do formulário

        // Coleta os dados dos campos do formulário
        var formData = new FormData(form);
        var data = {};

        formData.forEach(function (value, key) {
            // Remove o prefixo dinâmico seguido de colchetes
            var cleanedKey = key.replace(/^[^\[]*\[(.*?)\]$/, '$1');
            data[cleanedKey] = value;
        });

        Object.keys(data).forEach(key => {
            if (typeof data[key] === 'string' && /^[\d,]+$/.test(data[key])) {
                data[key] = data[key].replace(",", ".");
            }
        });

        // Exibe os dados no console (ou pode enviar para um servidor, etc.)
        console.log(data);

        // Aqui você pode adicionar código para processar os dados ou enviá-los para um servidor

        confirmar(data, editable);
    });

    // Validação e feedback
    Array.from(form.elements).forEach(function (element) {
        element.addEventListener("input", function () {
            if (element.checkValidity()) {
                element.classList.remove("is-invalid");
                element.classList.add("is-valid");
            } else {
                element.classList.remove("is-valid");
                element.classList.add("is-invalid");
            }
        });
    });
}

// Função para verificar se todos os campos de um objeto são vazios
function todosCamposVazios(registro) {
    return Object.values(registro).every(campo => campo === "");
}


async function buscarDados(consulta, tabela) {

    document.getElementsByClassName("tabela")[0].style.display = "block";
    document.getElementsByClassName("formR")[0].style.display = "none";


    var query = consulta;

    if (tabela != "AD_CABANALISE") {
        query += ` WHERE NUANALISE = ${NROANALISE}`;

    }
    const preenchimento = "Em Preenchimento CQ";
    const emAnaliseCQ = "Em Conferência CQ";
    const emvalidacaoq = "Em Validação Qualidade"
    const retornoCQ = "Retornado Para CQ";
    const finalizado = "Concluído";
    const reprovConcluida = "Analise Reprovada / Concluída";


    if (tabela == "AD_CABANALISE") {

        query += ` WHERE 1 = 1`

        if (ANALISTACQ == 'S' && ANALISTAQUALDIADE == 'S' && CONFERENTE == 'S') {
            query += ` AND STATUS IN('Em Preenchimento CQ','Em Conferência CQ','Em Validação Qualidade','Retornado Para CQ','Concluído', 'Analise Reprovada / Concluída')`;

        } else {
            if (ANALISTACQ == 'S') {
                query += ` AND STATUS IN('Em Preenchimento CQ','Retornado Para CQ','Concluído', 'Analise Reprovada / Concluída')`
            }
            if (ANALISTAQUALDIADE == 'S') {
                query += ` AND STATUS IN('Em Validação Qualidade','Concluído', 'Analise Reprovada / Concluída')`;
            }
            if (CONFERENTE == 'S') {
                query += ` AND STATUS IN('Em Conferência CQ','Concluído', 'Analise Reprovada / Concluída')`;
            }
        }
        if (VALOR_FILTRO != "Selecione") {
            query += ` AND STATUS = '${VALOR_FILTRO}'`;
        }
        query += ` ORDER BY NUANALISE DESC`;

        console.log(query);
    }


    //console.log(query);

    executeQuery(query, [], function (value) {
        var dadosTabela = JSON.parse(value);
        //console.log("Qtd tabela")
        //console.log(dadosTabela)
        // Verificar o primeiro (ou todos) registros no array
        const resultado = dadosTabela.every(todosCamposVazios);

        if (dadosTabela.length > 0) {

            var colunasTabela = Object.keys(dadosTabela[0]);
            var nroColunas = colunasTabela.length;

            
            var table = document.getElementById("tabelaParceiros");
            table.innerHTML = "";
            table.className = "table table-Light";
            
            // Função para montar o cabeçalho da tabela
            montaHeaderTable(table, colunasTabela);


            if (resultado) {
                console.log("Todos os campos do registro estão vazios.");
                var table = document.getElementById("tabelaParceiros");
                var inputGroupNofound = document.createElement("p");
                inputGroupNofound.innerHTML = '<h2>Nenhum Registro Encontrado <i class="fa fa-exclamation-triangle fa-3x" aria-hidden="true" style="color: yellow;"></i><h2/>';
                inputGroupNofound.className = "mensagemSemDados";
                table.appendChild(inputGroupNofound);
            } else {

                for (var k in dadosTabela) {
                    var row = table.insertRow(-1);

                    // Inserir os dados nas células
                    for (var j in dadosTabela[k]) {
                        row.insertCell(-1).innerHTML = dadosTabela[k][j];
                    }

                    // Criar um botão para trazer as informações daquela linha
                    // Criar a célula "Ações"
                    var actionsCell = row.insertCell(-1);
                    actionsCell.style.width = "350px";



                    /* Enviar para Conferente */
                    var btnNext = document.createElement("button");
                    btnNext.innerHTML = '<i class="fa fa-paper-plane" aria-hidden="true"></i>';
                    btnNext.style.color = '#FFF'
                    btnNext.className = "btn btn-info ml-2 mr-2";
                    btnNext.style.marginLeft = "5px";
                    btnNext.onclick = (function (linha) {
                        return function () {

                            var infoLinha = dadosTabela[linha];
                            //cq - Envia Conferente
                            acaoBotao(infoLinha, 'cq');

                        };
                    })(k);

                    /* Botão conferencia OK próxima etapa */
                    var btnConf = document.createElement("button");
                    btnConf.innerHTML = '<i class="fa fa-check" aria-hidden="true"></i>';
                    btnConf.style.color = '#FFF'
                    btnConf.className = "btn btn-success ml-2 mr-2";
                    btnConf.style.marginLeft = "5px";
                    btnConf.onclick = (function (linha) {
                        return function () {

                            var infoLinha = dadosTabela[linha];

                            // ccq - Conferencia OK
                            acaoBotao(infoLinha, 'ccq');

                        };
                    })(k);


                    /* Retornar para CQ e Conferente */
                    var btnret = document.createElement("button");
                    btnret.innerHTML = '<i class="fa fa-reply-all" aria-hidden="true"></i>';
                    btnret.style.color = '#FFF'
                    btnret.className = "btn btn-warning ml-2 mr-2";
                    btnret.style.marginLeft = "5px";
                    btnret.onclick = (function (linha) {
                        return function () {

                            var infoLinha = dadosTabela[linha];

                            //RQ - Retorno para preenchedores
                            acaoBotao(infoLinha, 'rq');

                        };
                    })(k);

                    /* Concluí o relatório completamente. */
                    var btnConc = document.createElement("button");
                    btnConc.innerHTML = '<i class="fa fa-key" aria-hidden="true"></i>';
                    btnConc.style.color = '#FFF'
                    btnConc.className = "btn btn-success ml-2 mr-2";
                    btnConc.style.marginLeft = "5px";
                    btnConc.onclick = (function (linha) {
                        return function () {

                            var infoLinha = dadosTabela[linha];

                            // c - Concluir sem ressalvas
                            acaoBotao(infoLinha, 'c');

                        };
                    })(k);


                    /* Botões com ampla usabilidade */
                    /* Editar */
                    var btnEdit = document.createElement("button");
                    btnEdit.innerHTML = '<i class="fa fa-pen"></i>';
                    btnEdit.className = "btn btn-light mr-2 text-dark";
                    btnEdit.onclick = (function (linha) {
                        return function () {

                            var infoLinha = dadosTabela[linha];

                            // e - editar
                            acaoBotao(infoLinha, 'e');

                        };
                    })(k);
                    /* Analisar */
                    var btnAna = document.createElement("button");
                    btnAna.innerHTML = '<i class="fa fa-search"></i>';
                    btnAna.className = "btn btn-danger ml-2 mr-2";
                    btnAna.style.marginLeft = "5px";
                    btnAna.title = "Analisar";
                    btnAna.onclick = (function (linha) {
                        return function () {

                            var infoLinha = dadosTabela[linha];

                            // a - analisar
                            acaoBotao(infoLinha, 'a');

                        };
                    })(k);

                    /* Botão Fechar Analise - Reprovada */
                    var btnReprova = document.createElement("button");
                    btnReprova.innerHTML = '<i class="fa fa fa-times" aria-hidden="true"></i>';
                    btnReprova.style.color = '#FFF'
                    btnReprova.className = "btn btn-danger ml-2 mr-2";
                    btnReprova.style.marginLeft = "5px";
                    btnReprova.onclick = (function (linha) {
                        return function () {

                            var infoLinha = dadosTabela[linha];

                            // roc - Reprova, Observação, Concluí.
                            acaoBotao(infoLinha, 'roc');

                        };
                    })(k);

                    /* Botão para ver logs */
                    var btnLogs = document.createElement("button");
                    btnLogs.innerHTML = '<i class="fa fa-list-alt" aria-hidden="true"></i>';
                    btnLogs.style.color = '#FFF'
                    btnLogs.className = "btn btn-info ml-2 mr-2";
                    btnLogs.style.marginLeft = "5px";
                    btnLogs.onclick = (function (linha) {
                        return function () {

                            var infoLinha = dadosTabela[linha];

                            // log 0- Log das informações do cabeçalho
                            acaoBotao(infoLinha, 'log');

                        };
                    })(k);


                    /* Botão Impressora */
                    var btnImpressao = document.createElement("button");
                    btnImpressao.innerHTML = '<i class="fa fa-print"></i>';
                    btnImpressao.className = "btn btn-primary  ml-2 mr-2";
                    btnImpressao.style.marginLeft = "5px";
                    btnImpressao.onclick = (function (linha) {
                        return function () {

                            var infoLinha = dadosTabela[linha];

                            // i - Impressão
                            acaoBotao(infoLinha, 'i');

                        };
                    })(k);

                    /*  
                    preenchimento = "Em Preenchimento CQ";
                    emAnaliseCQ = "Em Conferência CQ";
                    emvalidacaoq = "Em Validação Qualidade"
                    retornoCQ = "Retornado Para CQ";
                    finalizado = "Concluído";
                    reprovConcluida = "Analise Reprovada / Concluída"; 
                    */

                    if (tabelaAtual == "AD_CABANALISE") {

                        if (ANALISTACQ == 'S') {
                            if (dadosTabela[k]['Status'] == preenchimento) {
                                actionsCell.append(btnEdit, btnAna, btnNext, btnLogs);
                            } else if (dadosTabela[k]['Status'] == retornoCQ) {
                                actionsCell.append(btnEdit, btnAna, btnNext, btnLogs);
                            }
                        }

                        if (ANALISTAQUALDIADE == 'S') {
                            if (dadosTabela[k]['Status'] == emvalidacaoq) {
                                actionsCell.append(btnAna, btnret, btnReprova, btnConc, btnLogs);
                            }
                        }

                        if (CONFERENTE == 'S') {
                            if (dadosTabela[k]['Status'] == emAnaliseCQ) {
                                actionsCell.append(btnAna,btnEdit, btnConf, btnReprova, btnLogs);
                            }
                        }


                        //reprovConcluida = "Analise Reprovada / Concluída"; 
                        if (dadosTabela[k]['Status'] == reprovConcluida) {
                            actionsCell.append(btnAna, btnLogs);
                        }
                        //finalizado = "Concluído";
                        if (dadosTabela[k]['Status'] == finalizado) {
                            actionsCell.append(btnAna, btnLogs);
                        }

                        if (IMPRESSAO == 'S') {
                            actionsCell.appendChild(btnImpressao);
                        }

                    } else {

                        if (STATUS == preenchimento) {
                            actionsCell.appendChild(btnEdit);
                        } else if (STATUS == retornoCQ) {
                            actionsCell.appendChild(btnEdit);
                        }
                    }
                }

            }


        }
    }, function (value) {
        alert(value);
    });
}


function montaHeaderTable(table, columns) {
    var header = table.createTHead();
    var rowHeader = header.insertRow(0);

    columns.forEach(function (column) {
        var cell = rowHeader.insertCell(-1);
        cell.innerHTML = "<b>" + column + "</b>";
        cell.className = "table-dark"; // Estilo para o header
        // Definindo estilos diretamente no elemento
        cell.style.position = "sticky"; // Faz o cabeçalho ficar fixo
        cell.style.top = "0"; // Mantém o cabeçalho no topo do contêiner
        //cell.style.backgroundColor = "#f8f9fa"; // Cor de fundo do cabeçalho
        cell.style.zIndex = "10"; // Garante que o cabeçalho fique acima dos registros
        cell.style.padding = "2px"; // Espaçamento do cabeçalho
        cell.style.borderBottom = "2px solid #dee2e6"; // Linha de separação inferior
        
    });

    // Adiciona a coluna "Ações"
    var actionsCell = rowHeader.insertCell(-1);
    actionsCell.innerHTML = "<b>Ações</b>";
    actionsCell.className = "table-dark";
    actionsCell.style.width = "100px"; 
    actionsCell.style.position = "sticky"; // Faz o cabeçalho ficar fixo
    actionsCell.style.top = "0"; // Mantém o cabeçalho no topo do contêiner
    //actionsCell.style.backgroundColor = "#f8f9fa"; // Cor de fundo do cabeçalho
    actionsCell.style.zIndex = "10"; // Garante que o cabeçalho fique acima dos registros
    actionsCell.style.padding = "10px"; // Espaçamento do cabeçalho
    actionsCell.style.borderBottom = "2px solid #dee2e6"; // Linha de separação inferior



}


async function CamposDinamicos(tabela) {
    tabelaAtual = tabela;

    if (tabela == "AD_CABANALISE") {
        limparDivAnalises();
    }
    try {

        // Construir a consulta
        var query = `SELECT consulta_dinamica_tabela('${tabela}') AS CONSULTA FROM DUAL`;


        // Executar a consulta usando a biblioteca JX
        let resultado = await JX.consultar(query);

        if (resultado.length == 0) { return; }
        else { resultado = resultado[0]; }

        // Mostrar o resultado
        //console.log(resultado.CONSULTA);
        buscarDados(resultado.CONSULTA, tabela);

    } catch (error) {
        console.error('Erro ao executar a consulta:', error);
    }
}


async function buscarChavesPrimarias(tabela) {
    try {

        // Construir a consulta
        var query = `SELECT DESCRCAMPO,NOMECAMPO  FROM TDDCAM WHERE (NOMETAB, NOMECAMPO) IN ( SELECT a.table_name, a.column_name FROM all_cons_columns a  JOIN all_constraints c ON a.constraint_name = c.constraint_name WHERE c.constraint_type = 'P' AND a.table_name = '${tabela}') `

        console.log(query)
        // Executar a consulta usando a biblioteca JX
        let resultado = await JX.consultar(query);

        if (resultado.length == 0) { return; }
        else { resultado = resultado; }

        // Mostrar o resultado
        console.log(resultado);
        // Construa a string para o onclick
        /*  let chaves = resultado.map(item => `dadosTabela[k]["${item.DESCRCAMPO}"]`).join(", ");
     
         console.log(chaves) */
        // Retorne a string HTML com o onclick formatado corretamente
        return resultado;



    } catch (error) {
        console.error('Erro ao executar a consulta:', error);
    }
}

let linhaCro = "";
let condicaoCro = "";
async function acaoBotao(linha, condicao) {

    // cro - Reprova, Observação, Concluí.
    if (condicao == 'e') {
        editar(linha);
    } else
        if (condicao == 'a') {
            analisar(linha);
        }
        else
            if (condicao == 'i') {
                abrirImpressao(linha);
            }
            else if (condicao == 'roc') {
                linhaCro = linha;
                condicaoCro = condicao;
                AbrirPop();
            }
            else if (condicao == 'log') {

                var queryBusca = `SELECT consulta_dinamica_tabela('AD_LOGSCABANALISE') AS CONSULTA FROM DUAL`;

                let resultadoBusca = await JX.consultar(queryBusca);
                console.log("Resultado da consulta dinâmica:", resultadoBusca); // Verifica o resultado

                let nroAnalise = Number(linha['Nro. Único Analise']);
                let queryRegistro = resultadoBusca[0]["CONSULTA"] + ` WHERE NUANALISE = ${nroAnalise} ORDER BY DATALOG DESC`;

                console.log("Consulta de registro:", queryRegistro); // Verifica a string SQL gerada


                executeQuery(queryRegistro, [], function (value) {
                    try {
                        var dadosTabela = JSON.parse(value);

                        console.log(dadosTabela)

                        var colunasTabela = Object.keys(dadosTabela[0]);

                        console.log(colunasTabela);

                        if (dadosTabela.length == 0) { return; }
                        else { PopUPTable(colunasTabela, dadosTabela); }
                        // Continue a processar dadosTabela aqui
                    } catch (e) {
                        console.error("Erro ao analisar JSON:", e);
                        console.log("Valor retornado:", value); // Verifica o valor retornado
                    }
                });


                /*  
 
                 // Executar a consulta usando a biblioteca JX
                 if (resultadoRegistro.length == 0) { return; }
                 else { PopUPTable(colunasTabela, resultadoRegistro); } */
            }
            else {
                updateStatus(linha, condicao, '');
            }
}


async function analisar(linha) {

    console.log(linha);
    NROPRODUCAO = linha['Nro. Ordem de Produção'];
    NROANALISE = linha['Nro. Único Analise'];
    STATUS = linha['Status'];
    //let status = linha['Status'];

    var queryBusca = `SELECT PA.CODPRODPA, PA.QTDPRODUZIR, PA.NROLOTE, PRO.DESCRPROD FROM TPRIPA PA INNER JOIN TGFPRO PRO ON PA.CODPRODPA = PRO.CODPROD WHERE PA.IDIPROC = '${NROPRODUCAO}'`;
    let dados = await JX.consultar(queryBusca);

    if (dados.length == 0) {
        limparDivAnalises();
        return;
    }
    else { dados = dados[0]; }

    console.log(dados.CODPRODPA)

    var queryListaAnalises = `SELECT ANAP.NOMETABELA, INS.DESCRINSTANCIA FROM AD_ANALISEPRODUTO ANAP INNER JOIN TDDINS INS ON ANAP.NOMETABELA = INS.NOMETAB WHERE CODPROD = '${dados.CODPRODPA}'`;
    let analises = await JX.consultar(queryListaAnalises);

    if (analises.length == 0) { return; }
    else {
        // Obter a div com um certo id onde os links serão inseridos
        var div = document.getElementById("analises"); // Substitua 'idDaDiv' pelo ID da sua div

        // Limpar o conteúdo da div
        div.innerHTML = "";

        for (var k in analises) {

            var analise = analises[k];

            console.log(analise['DESCRINSTANCIA']);

            // Cria o container para os botões
            var inputGroup = document.createElement("div");
            inputGroup.className = "input-group mb-3";
            inputGroup.style.paddingLeft = "16px";

            // Cria o container para os botões dentro do input-group
            var inputGroupAppend = document.createElement("div");
            inputGroupAppend.className = "input-group-append";

            // Criar o botão para chamar os registros
            var btnRegistros = document.createElement("button");
            btnRegistros.innerHTML = analise['DESCRINSTANCIA'] + '  <i class="fa fa-list" style="color: white;"></i>';
            btnRegistros.className = "btn btn-info";
            btnRegistros.style.flex = "1"; // Faz o botão ocupar o espaço restante
            btnRegistros.style.marginLeft = "5px"
            btnRegistros.addEventListener("click", (function (nometabela) {
                return function () {
                    CamposDinamicos(nometabela);
                };
            })(analise['NOMETABELA']));

            var btnFormulario = document.createElement("button");
            btnFormulario.innerHTML = '<i class="fa fa-plus-square fa-2x" aria-hidden="true"></i>';
            btnFormulario.className = "btn";
            btnFormulario.style.color = "#FFF";
            btnFormulario.style.width = "40px"; // Define uma largura fixa para o botão "+"

            btnFormulario.addEventListener("click", (function (nometabela) {
                return function () {
                    novo(nometabela);
                };
            })(analise['NOMETABELA']));

            // Adiciona os botões ao container 'input-group-append'
            if (STATUS != finalizado && ANALISTACQ == 'S') {
                inputGroupAppend.appendChild(btnFormulario);
            }

            inputGroupAppend.appendChild(btnRegistros);


            // Adiciona o container 'input-group-append' ao 'input-group'
            inputGroup.appendChild(inputGroupAppend);

            // Adiciona o container 'input-group' à div onde você quer inserir os botões
            div.appendChild(inputGroup);

        }

        /* Mostrando o BOX com as informações da analise do momento sendo feita */
        // Obter a div com um certo id onde as informações serão inseridas
        var box = document.getElementById("boxgroup");
        // Limpar o conteúdo da div
        box.innerHTML = "";
        var inputGroupBox = document.createElement("p");
        var inputhr = document.createElement("hr");
        inputGroupBox.innerHTML = "<h6>Nro da Analise: " + NROANALISE + "<h6/><br>" + "<p>Produto em Analise: <p/>" + dados.CODPRODPA + " - " + dados.DESCRPROD + "<br>" + "<p>Ordem de Produção: " + NROPRODUCAO + "<p/>";

        box.appendChild(inputGroupBox);
        box.appendChild(inputhr);

    }


}


async function editar(linha) {

    console.log(linha)

    // Construir a consulta
    var query = `SELECT NOMECAMPO,DESCRCAMPO FROM TDDCAM WHERE NOMETAB = '${tabelaAtual}'`;

    // Executar a consulta usando a biblioteca JX
    let resultado = await JX.consultar(query);
    console.log("Tabela");
    console.log(tabelaAtual);
    console.log("Resultado");
    console.log(resultado);

    const retorno = renomearChave(linha, resultado);
    console.log("Retorno");
    console.log(retorno);
    // Oculta a tabela e exibe o formulário
    document.getElementsByClassName("tabela")[0].style.display = "none";
    document.getElementsByClassName("formR")[0].style.display = "block";

    // Carrega os campos e preenche com os dados da linha
   /*  var query = `SELECT CAM.NOMECAMPO, CAM.NOMETAB, CAM.DESCRCAMPO, CASE WHEN CAM.TIPCAMPO = 'S' THEN 'text' WHEN CAM.TIPCAMPO = 'D' THEN 'date' WHEN CAM.TIPCAMPO = 'I' THEN 'number' END AS TIPO, `;
    query += ` AD_REQUERIDO(CAM.NOMETAB,CAM.NOMECAMPO) AS OBRIGATORIO, AD_READONLY(CAM.NOMETAB,CAM.NOMECAMPO) AS READ, MINMAX.MIN, MINMAX.MAX FROM TDDCAM CAM LEFT JOIN AD_CAMPOSMINMAX MINMAX ON CAM.NOMETAB = MINMAX.NOMETABELA AND CAM.NOMECAMPO = MINMAX.NOMECAMPO `;
    query += ` WHERE CAM.NOMETAB = '${tabelaAtual}' AND CAM.CALCULADO = 'N' ORDER BY CAM.ORDEM ASC`; */

    var query = `SELECT CASE WHEN CAM.TIPCAMPO = 'F' THEN 'S' ELSE 'N' END AS STEP, CAM.NOMECAMPO, CAM.NOMETAB, CAM.DESCRCAMPO, CASE WHEN CAM.TIPCAMPO = 'S' THEN 'text' WHEN CAM.TIPCAMPO = 'D' THEN 'date' WHEN CAM.TIPCAMPO IN ('I','F') THEN 'number' END AS TIPO, `;
    query += ` AD_REQUERIDO(CAM.NOMETAB,CAM.NOMECAMPO) AS OBRIGATORIO, AD_READONLY(CAM.NOMETAB,CAM.NOMECAMPO) AS READ, MINMAX.MIN, MINMAX.MAX FROM TDDCAM CAM LEFT JOIN AD_CAMPOSMINMAX MINMAX ON CAM.NOMETAB = MINMAX.NOMETABELA AND CAM.NOMECAMPO = MINMAX.NOMECAMPO `;
    query += ` WHERE CAM.NOMETAB = '${tabelaAtual}' AND CAM.CALCULADO = 'N' ORDER BY CAM.ORDEM ASC`;

    executeQuery(query, [], function (value) {
        var dadosTabela = JSON.parse(value);
        if (dadosTabela.length > 0) {
            var formularioDiv = document.getElementById("formulario");
            formularioDiv.innerHTML = "";
            // Chama a função criarFormulario passando os dados da linha selecionada
            criarFormulario(dadosTabela, retorno);
        }
    }, function (error) {
        alert("Erro ao carregar os dados: " + error);
    });
}


function renomearChave(objeto, mapeamento) {
    const novoObjeto = {};

    // Percorre cada chave atual do objeto
    for (let chaveAntiga in objeto) {
        // Encontra o item correspondente no mapeamento
        let mapeamentoItem = mapeamento.find(item => item.DESCRCAMPO === chaveAntiga);

        if (mapeamentoItem) {
            // Substitui a chave pela NOMECAMPO correspondente
            novoObjeto[mapeamentoItem.NOMECAMPO] = objeto[chaveAntiga];
        } else {
            // Mantém a chave original se não houver mapeamento
            novoObjeto[chaveAntiga] = objeto[chaveAntiga];
        }
    }

    return novoObjeto;
}



function showLoadingBox() {
    document.getElementById("loadingBox").style.display = "block";
}

// Função para ocultar a caixa de "salvando"
function hideLoadingBox() {
    document.getElementById("loadingBox").style.display = "none";
}



async function confirmar(dados, editable) {
    // Exibe a caixa "salvando"
    showLoadingBox();


    if (editable == true) {
        const objetoChavePrimaria = await gerandoChavePk(dados);

        console.log(objetoChavePrimaria);

        //const salvamentoBipagem = await JX.salvar(dados, 'AD_REGISTPRODUCAO', {NROOP: "32", NROREGIST: "1"});


        JX.salvar(dados, tabelaAtual, objetoChavePrimaria)
            .then(response => {
                console.log("Registro atualizado com sucesso:", response);
                toastr.success('Atualização realizada com sucesso!', 'Sucesso');
                CamposDinamicos(tabelaAtual);
                hideLoadingBox(); // Esconde a caixa
            })
            .catch(error => {
                console.error("Erro ao atualizar o registro:", error);
                toastr.error('Ocorreu um erro ao realizar a Atualização.', 'Erro');
                hideLoadingBox(); // Esconde a caixa

            });
    } else {

        if (tabelaAtual == 'AD_CABANALISE') {

            dados.STATUS = preenchimento;
            dados.USUARIOCRIACAO = USUARIO;

            JX.salvar(dados, tabelaAtual)
                .then(response => {
                    console.log("Registro atualizado com sucesso:", response);
                    toastr.success('Registro realizado com sucesso!', 'Sucesso');
                    CamposDinamicos(tabelaAtual);
                    hideLoadingBox(); // Esconde a caixa
                })
                .catch(error => {
                    console.error("Erro ao atualizar o registro:", error);
                    toastr.error('Ocorreu um erro ao realizar o registro.', 'Erro');
                    hideLoadingBox(); // Esconde a caixa

                });
        } else {

            const dadosTratados = await vincularChavePrimaria(dados);

            JX.salvar(dadosTratados, tabelaAtual)
                .then(response => {
                    console.log("Registro atualizado com sucesso:", response);
                    toastr.success('Operação realizada com sucesso!', 'Sucesso');
                    CamposDinamicos(tabelaAtual);
                    hideLoadingBox(); // Esconde a caixa
                })
                .catch(error => {
                    console.error("Erro ao atualizar o registro:", error);
                    toastr.error('Ocorreu um erro ao realizar a operação.', 'Erro');
                    hideLoadingBox(); // Esconde a caixa

                });

        }
    }
}

async function vincularChavePrimaria(dados) {
    console.log(dados);
    console.log(NROANALISE);

    // Verifica se a chave 'NROCAB' existe no objeto
    if (dados.hasOwnProperty('NUANALISE')) {
        // Substitui o valor da chave 'NROCAB' com o valor da variável NROANALISE
        dados['NUANALISE'] = NROANALISE;
    }

    // Retorna o objeto atualizado
    //console.log(dados);
    return dados;
}


async function gerandoChavePk(dadosLinha) {
    try {
        // Buscar as chaves primárias da tabela
        const chavesPrimarias = await buscarChavesPrimarias(tabelaAtual);

        if (!chavesPrimarias || chavesPrimarias.length === 0) {
            console.log('Nenhuma chave primária encontrada.');
            return;
        }

        // Criar um objeto com as chaves primárias e seus valores
        let objetoChavesPrimarias = {};

        chavesPrimarias.forEach(chave => {
            const nomeCampo = chave.NOMECAMPO;
            const valorCampo = dadosLinha[nomeCampo];
            objetoChavesPrimarias[nomeCampo] = valorCampo;
        });

        // Retorna o objeto com as chaves primárias e valores correspondentes
        console.log('Objeto com chaves primárias:', objetoChavesPrimarias);
        return objetoChavesPrimarias;

    } catch (error) {
        console.error('Erro ao gerar chaves primárias:', error);
    }
}



function limparDivAnalises() {

    // Obter a div com um certo id onde os links serão inseridos
    var div = document.getElementById("analises"); // Substitua 'idDaDiv' pelo ID da sua div
    var box = document.getElementById("boxgroup");

    // Limpar o conteúdo da div
    div.innerHTML = "";
    box.innerHTML = "";

}


function abrirImpressao(linha) {

    let nroAnalise = Number(linha['Nro. Único Analise']);

    console.log(nroAnalise)
    var params = { 'NUANALISE': nroAnalise };
    console.log(params)


    openLevel('lvl_b6o80j', params);
}


async function updateStatus(linha, condicao, obsreprova) {



    // Construir a consulta
    var query = `SELECT NOMECAMPO,DESCRCAMPO FROM TDDCAM WHERE NOMETAB = '${tabelaAtual}'`;

    // Executar a consulta usando a biblioteca JX
    let resultado = await JX.consultar(query);
    console.log("Tabela");
    console.log(tabelaAtual);
    console.log("Resultado");
    console.log(resultado);

    const retorno = renomearChave(linha, resultado);

    console.log(retorno);
    console.log("Alterando");
    console.log(condicao);

    //cq - Envia Conferente
    // ccq - Conferencia OK
    //rq - Retorno para preenchedores
    // c - Concluir sem ressalvas


    /*  
     preenchimento = "Em Preenchimento CQ";
     emAnaliseCQ = "Em Conferência CQ";
     emvalidacaoq = "Em Validação Qualidade"
     retornoCQ = "Retornado Para CQ";
     finalizado = "Concluído";
     reprovConcluida = "Analise Reprovada / Concluída"; 
     */


    if (condicao == "cq") {
        retorno.STATUS = emAnaliseCQ;

    } else if (condicao == "ccq") {
        retorno.STATUS = emvalidacaoq;
        retorno.CONFERIDOPOR = USUARIO;
    }
    else if (condicao == "rq") {
        retorno.STATUS = retornoCQ;
        retorno.USUARIOANALISE = USUARIO;
    }
    else if (condicao == "c") {

        retorno.STATUS = finalizado;
        retorno.USUARIOCONCLUSAO = USUARIO;

    }
    else if (condicao == "roc") {
        retorno.STATUS = reprovConcluida;
        retorno.OBSREPROVA = obsreprova;
        retorno.USUARIOCONCLUSAO = USUARIO;
        retorno.USUARIOREPROVACAO = USUARIO;
    }

    confirmar(retorno, true)

    //console.log(retorno)
}

function capturarValor() {
    // Obtém o elemento select pelo ID
    var select = document.getElementById("statusSelect");
    // Obtém o valor selecionado
    var valorSelecionado = select.value;
    // Exibe o valor no console ou manipula conforme necessário

    VALOR_FILTRO = valorSelecionado;


    console.log(valorSelecionado);

    CamposDinamicos('AD_CABANALISE');
}


function AbrirPop() {

    document.getElementsByClassName("boxObservation")[0].style.visibility = "visible";
}

function FecharPop() {

    document.getElementsByClassName("boxLogsCss")[0].style.visibility = "hidden";
    document.getElementsByClassName("boxObservation")[0].style.visibility = "hidden";
    document.getElementById("caixa_obs").value = "";

}





function valorPopUp() {

    var valor_obs = document.getElementById("caixa_obs").value;

    console.log(linhaCro)
    console.log(condicaoCro)
    console.log(valor_obs)
    updateStatus(linhaCro, condicaoCro, valor_obs);

    FecharPop();

}


function PopUPTable(headers, data) {

    document.getElementsByClassName("boxLogsCss")[0].style.visibility = "visible";

    // Seleciona o contêiner onde a tabela será inserida
    const container = document.getElementById("boxLogs");
    container.innerHTML = ""; // Limpa o conteúdo do contêiner, caso já exista uma tabela

    // Cria o contêiner responsivo
    const responsiveDiv = document.createElement("div");
    responsiveDiv.classList.add("table-responsive");

    // Cria o elemento da tabela
    const table = document.createElement("table");
    table.classList.add("table", "table-striped", "custom-table");
    table.style.zIndex = "10000"; // Define o z-index diretamente no estilo

    // Cria o cabeçalho da tabela
    const thead = document.createElement("thead");
    const headerRow = document.createElement("tr");

    headers.forEach(header => {
        const th = document.createElement("th");
        th.textContent = header;
        headerRow.appendChild(th);
    });

    thead.appendChild(headerRow);
    table.appendChild(thead);

    // Cria o corpo da tabela
    const tbody = document.createElement("tbody");

    data.forEach(rowData => {
        const row = document.createElement("tr");

        headers.forEach(header => {
            const cell = document.createElement("td");
            cell.textContent = rowData[header] || ""; // Insere o valor da célula ou vazio
            row.appendChild(cell);
        });

        tbody.appendChild(row);
    });

    table.appendChild(tbody);

    // Adiciona a tabela ao contêiner responsivo
    responsiveDiv.appendChild(table);

    // Define a altura do contêiner e adiciona ao contêiner específico
    container.appendChild(responsiveDiv);
}



