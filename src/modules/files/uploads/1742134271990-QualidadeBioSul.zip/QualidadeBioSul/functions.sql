CREATE OR REPLACE FUNCTION AD_REQUERIDO(p_table_name IN VARCHAR2, p_campo IN VARCHAR2) 
RETURN VARCHAR2 
IS
    v_read VARCHAR2(5);
    V_NROCAMPO NUMBER;
BEGIN
    -- Obtém o número do campo baseado na tabela e nome do campo
    SELECT NUCAMPO 
    INTO V_NROCAMPO 
    FROM TDDCAM 
    WHERE NOMETAB = p_table_name AND NOMECAMPO = p_campo;

    -- Verifica se o campo é somente leitura
    SELECT CASE WHEN VALOR = 'S' THEN 'true' ELSE 'false' END 
    INTO v_read 
    FROM TDDPCO 
    WHERE NUCAMPO = V_NROCAMPO AND NOME = 'requerido';

    -- Retorna a informação se o campo é somente leitura
    RETURN v_read;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN 'false'; -- Ou outro valor padrão, se não encontrar dados
    WHEN OTHERS THEN
        RETURN 'false'; -- Retorna false em caso de outros erros
END;

/



CREATE OR REPLACE FUNCTION consulta_dinamica_tabela(p_table_name IN VARCHAR2) 
RETURN VARCHAR2 
IS
    v_mensagem VARCHAR2(5000);  -- Variável para armazenar a mensagem
    v_sql VARCHAR2(4000); 
BEGIN

    BEGIN
    SELECT LISTAGG(NOMECAMPO || ' AS "' || DESCRCAMPO || '"', ', ') 
           WITHIN GROUP (ORDER BY NOMECAMPO)
    INTO v_sql
    FROM tddcam
    WHERE NOMETAB = p_table_name AND CALCULADO = 'N';
    END;

    -- Construir a mensagem
    v_mensagem := 'SELECT ' || v_sql || ' FROM ' || p_table_name;

    -- Retornar a mensagem
    RETURN v_mensagem;
END;
/


CREATE OR REPLACE FUNCTION AD_READONLY(p_table_name IN VARCHAR2, p_campo IN VARCHAR2) 
RETURN VARCHAR2 
IS
    v_read VARCHAR2(5);
    V_NROCAMPO NUMBER;
BEGIN
    -- Obtém o número do campo baseado na tabela e nome do campo
    SELECT NUCAMPO 
    INTO V_NROCAMPO 
    FROM TDDCAM 
    WHERE NOMETAB = p_table_name AND NOMECAMPO = p_campo;

    -- Verifica se o campo é somente leitura
    SELECT CASE WHEN VALOR = 'S' THEN 'true' ELSE 'false' END 
    INTO v_read 
    FROM TDDPCO 
    WHERE NUCAMPO = V_NROCAMPO AND NOME = 'readOnly';

    -- Retorna a informação se o campo é somente leitura
    RETURN v_read;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN 'false'; -- Ou outro valor padrão, se não encontrar dados
    WHEN OTHERS THEN
        RETURN 'false'; -- Retorna false em caso de outros erros
END;
/